### Hexlet tests and linter status:
[![Actions Status](https://github.com/BobKelsoGIT/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/BobKelsoGIT/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/d05f011db4d749862e50/maintainability)](https://codeclimate.com/github/BobKelsoGIT/python-project-49/maintainability)

Демонстрация игр «Проверка на чётность» и «Калькулятор»:

[![asciicast](https://asciinema.org/a/UgZ1uL9Cbl02cyUknAaehthFO.svg)](https://asciinema.org/a/UgZ1uL9Cbl02cyUknAaehthFO)
